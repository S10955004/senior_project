const express = require('express');
const path = require('path');
const { Configuration, OpenAIApi } = require('openai');
require('dotenv').config();

const app = express();
const publicPath = path.join(__dirname, 'public');

app.use(express.static(publicPath));
app.use(express.json());

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

let conversationHistory = []; // 儲存對話歷史

async function runCompletion(prompt) {
  const completion = await openai.createCompletion({
    model: 'text-davinci-003',
    prompt,
    max_tokens: 4000,
  });
  return completion.data.choices[0].text;
}

app.post('/api/dialogue', async (req, res) => {
  try {
    const userInput = req.body.userInput;
    conversationHistory.push({ role: 'User', content: userInput });
    console.log('Received userInput:', userInput);

    const prompt = conversationHistory
      .map((message) => `${message.role}: ${message.content}`)
      .join('\n');

    const aiResponse = await runCompletion(prompt);
    conversationHistory.push({ role: 'AI', content: aiResponse });

    res.json({ response: aiResponse });

  } catch (error) {
    console.error('An error occurred while sending the message:', error);
    res.status(500).json({ error: 'An error occurred while sending the message' });
  }
  console.error('An error occurred:', error);

});

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});




  